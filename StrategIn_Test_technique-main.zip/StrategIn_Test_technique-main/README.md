# StrategIn_Test_technique
Voilà mon rendu pour le test technique de Strateg'In.
